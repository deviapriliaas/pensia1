<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />
	<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/footer-distributed-with-address-and-phones.css');?>">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
	<title> Hukum </title>
	<link rel="shortcut icon" type="image/jpg"href="<?php echo base_url('assets/P.jpg');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>" >
	
	</head>
<body>
		<div class="col-12" bgcolor="#333">
			<image src="<?php echo base_url('assets/image/PeNsia.png');?>">
		</div>
		<div class="navbar">
			<div class="col-12">
				<div class="col-2">
				<a href="<?php echo site_url('welcome/index');?>">Home</a>
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn">Do More 
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/care');?>">Caring </a>
						  <a href="<?php echo site_url('welcome/share');?>">Sharing</a>
						  <a href="<?php echo site_url('welcome/help');?>">Helping</a>
						</div>
					</div> 
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn">E-Nsia 
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/sos');?>">Sosial</a>
						  <a href="<?php echo site_url('welcome/psi');?>">Psikologi</a>
						  <a href="<?php echo site_url('welcome/kes');?>">Kesehatan</a>
						</div>
					</div> 
				</div>
			<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/hukum');?>">Hukum</a>
					</div>
				</div>
				<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/adu');?>">Pengaduan</a>
					</div>
				</div>
				<div class="col-2">
				<div class="alig">
					<a href="<?php echo site_url('welcome/login');?>">Login</a>
				</div>	
				</div>
			</div>
		</div>

			<div class="col-12">
				<h1> Hukum </h1>
			</div>	
			<div class="col-12">
			<div class="sembunyi">
				<div id="slider">
			<div id="slide-holder">
				<div class="slide"><img src="<?php echo base_url('assets/image/LH1.png');?>" alt="" /></div>
				<div class="slide"><img src="<?php echo base_url('assets/image/LH2.png');?>" alt="" /></div>
				<div class="slide"><img src="<?php echo base_url('assets/image/LH3.png');?>" alt="" /></div>
			</div>
				</div>
			</div>	
			</div>
			<div class="col-12">
			<div class="col-4">
			<div class="box1">
				<p> Devi </p>
			</div>
			</div>
			<div class="col-4">
				<div class="box1">
				<p> Devi </p>
				</div>
			</div>
			<div class="col-4">
				<div class="box1">
				<p> Devi </p>
			</div>
			</div>
	<div class="col-12">
<footer class="footer-distributed">

			<div class="footer-left">

				<img src="<?php echo base_url('assets/image/PeNsia.png');?>" style="width:100%">
				<br>
				<br>
				<br>
				<br>

				<p class="footer-company-name">PeNsia-Devi Aprilia Ayu S.; 2018</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Jl.Kaluta No.28</span> Malang,Indonesia</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+6288210820780</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">tugasku.devi@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About Founder</span>
					Hello Kenalkan Saya Devi Aprilia Ayu Santoso
					Saya Mahasiswi Manajemen Informatika
					Let me say that life is short and do best for you and around
				</p>

				<div class="footer-icons">

					<a href="https://www.facebook.com/devialde"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/deviaprilia_as"><i class="fa fa-twitter"></i></a>
					<a href="https://www.linkedin.com/in/devi-aprilia-ayu-santoso-149354163/"><i class="fa fa-linkedin"></i></a>

				</div>

			</div>
	</footer>
	</div>	
</body>
</html>