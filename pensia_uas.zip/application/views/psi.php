<html>
	<head>
	
	<title >E-NSia Psikologi</title>
	<link rel="shortcut icon" type="image/jpg"href="<?php echo base_url('assets/P.jpg');?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>" >
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />
	<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/footer-distributed-with-address-and-phones.css');?>">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/stylepsi.css');?>">
	
	</head>
<body>
		<div class="col-12">
			<image src="<?php echo base_url('assets/image/PeNsia.png');?>">
		</div>
				<div class="navbar">
			<div class="col-12">
				<div class="col-2">
				<a href="<?php echo site_url('welcome/index/');?>">Home</a>
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn">Do More
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/care/');?>">Caring </a>
						  <a href="<?php echo site_url('welcome/share/');?>">Sharing</a>
						  <a href="<?php echo site_url('welcome/help/');?>">Helping</a>
						</div>
					</div> 
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn"><div class="active">E-Nsia</div>
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/sos/');?>">Sosial</a>
						  <a href="<?php echo site_url('welcome/psi/');?>">Psikologi</a>
						  <a href="<?php echo site_url('welcome/kes/');?>">Kesehatan</a>
						</div>
					</div> 
				</div>
			<div class="col-2">
					<div class="sembunyi">
					<a href="hukum.html">Hukum</a>
					</div>
				</div>
				<div class="col-2">
					<div class="sembunyi">
					<a href="adu.html">Pengaduan</a>
					</div>
				</div>
				<div class="col-2">
				<div class="alig">
					<a href="login.html">Login</a>
				</div>	
				</div>
			</div>
		</div>
	<div class="col-12">
	<h2> Psikologi Pada Lansia</h2>
	</div>		
	<div class="col-12">
	<h3>Aspek Psikologi</h3>
	</div>
	<div class="col-4">
	<div class="box1">
		<h4>Aspek Intelektual </h4>
		<p> Penurunan kemampuan intelektual pada lansia adalah sesuatu yang tidak bisa terhindarkan. Hal ini disebabkan oleh beberapa faktor seperti penyakit, kecemasan ataupun depresi.
		Namun, kemampuan intelektual dapat dipertahankan dengan cara menciptakan lingkungan yang dapat melatih dan merangsang kemampuan intelektual mereka. 
		Cara tersebut juga bisa mengantisipasi terjadinya kepikunan pada mereka</p>
	</div>
	</div>
	
	<div class="col-4">
	<div class="box1">
		<h4>Aspek Emosional </h4>
		<p> Adanya perasaan tidak enak yang harus dihadapi oleh para lanjut usia seperti merasa tersisih, merasa tak dibutuhkan lagi,
		penyakit yang tak kunjung sembuh ataupun kematian pasangan akan menimbulkan rasa tidak percaya diri, depresi, 
		ketakutan sehingga lanjut usia sulit menyelesaikan suatu masalah dan melakukan penyesuaian diri.</p>
	</div>
	</div>
	
	<div class="col-4">
	<div class="box1">
		<h4>Aspek Spiritual </h4>
		<p> Beberapa penelitian menunjukan bahwa seseorang yang telah mencapai tahap usia lanjut akan lebih dekat dengan agama. 
		Hal ini menunjukan bahwa adanya tingginya level seperti dalam hal kepuasan dalam hidup, harga diri dan optimisme.
		Kebutuhan spiritual berpengaruh besar terhadap ketenangan batin para lansia begitu juga dalam hal kesehatan fisik maupun mental</p>
	</div>
	</div>
<div class="col-6">
<h3> Permasalahan Psikologi Lansia</h3>
	<div class="box12">
	<div class="teks">
	 1.Kesepian,biasanya lansia kesepian dikarenakan keluarganya yang sibuk dengan urusannya masing-masing.<br>
	2.Self Limiting,yakni depresi akibat duka cita ditinggal oleh orang terkasih misalnya pasangan hidup.<br>
	3.Parafenia, yakni bentuk kecurigaan yang terus menerus dilakukan terhadap orang lain.<br>
	4.Sindroma diganose,yakni tingkah laku lansia yang semakin aneh contohnya memainkan air seninya sendiri.<br>
	5.Kecemasan,biasanya kecemasan ini juga diakibatkan oleh obat ataupun sejenisnya
	</div>
	</div>
</div>	
<div class="col-6">
<h3> Solusi Psikologi Lansia</h3>
	<div class="box12">
	<div class="teks">
	1.Keluarga Harus memberikan perhatian terhadap lansia.<br>
	2.Lebih sering memberikan waktu untuk mereka.<br>
	3.Mengajak Lansia dalam kegiatan yang sebaya sehingga mereka tidak merasa sendiri.<br>
	4.Jika lansia mengalami gangguan mental maka harus dikonsultasikan pada psikiater atau sejenisnya.<br>
	5.Libatkan mereka dalam mengambil keputur=san ataupun kekegiatan keluarga agar mereka merasa lebih berguna.	
	<h6> Referensi By https://dosenpsikologi.com/psikologi-lansia</h6>
	</div>
	</div>
</div>
		
			
			
			
			
			
			
			
	<div class="col-12">
	<footer class="footer-distributed">

			<div class="footer-left">

				<img src="<?php echo base_url('assets/image/PeNsia.png');?>" style="width:100%">
				<br>
				<br>
				<br>
				<br>

				<p class="footer-company-name">PeNsia-Devi Aprilia Ayu S.; 2018</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Jl.Kaluta No.28</span> Malang,Indonesia</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+6288210820780</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">tugasku.devi@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About Founder</span>
					Hello Kenalkan Saya Devi Aprilia Ayu Santoso
					Saya Mahasiswi Manajemen Informatika
					Let me say that life is short and do best for you and around
				</p>

				<div class="footer-icons">

					<a href="https://www.facebook.com/devialde"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/deviaprilia_as"><i class="fa fa-twitter"></i></a>
					<a href="https://www.linkedin.com/in/devi-aprilia-ayu-santoso-149354163/"><i class="fa fa-linkedin"></i></a>

				</div>

			</div>
	</footer>
	</div>	
</body>
</html>