
<html>
	
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />
	<title> Login</title>
	<link rel="shortcut icon" type="image/jpg"href="<?php echo base_url('assets/P.jpg');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/footer-distributed-with-address-and-phones.css');?>">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
	<style>
		body{
	  padding:0;
	  margin:0;
	  background-image:url(<?php echo base_url('assets/image/P.png');?>);
	  background-repeat:no repeat;
	  background-position:center;
	 background-attachment: fixed;
	}
	.vid-container{
	  position:relative;
	  height:100vh;
	  overflow:hidden;
	}
	.bgvid.back {
	  position: fixed; right: 0; bottom: 0;
	  min-width: 100%; min-height: 100%;
	  width: auto; height: auto; z-index: -100;
	}
	.inner {
	  position: absolute;
	}
	.inner-container{
	  width:400px;
	  height:400px;
	  position:absolute;
	  top:calc(50vh - 200px);
	  left:calc(50vw - 200px);
	  overflow:hidden;
	}
	.bgvid.inner{
	  top:calc(-50vh + 200px);
	  left:calc(-50vw + 200px);
	  filter: url("data:image/svg+xml;utf9,<svg%20version='1.1'%20xmlns='http://www.w3.org/2000/svg'><filter%20id='blur'><feGaussianBlur%20stdDeviation='10'%20/></filter></svg>#blur");
	  -webkit-filter:blur(10px);
	  -ms-filter: blur(10px);
	  -o-filter: blur(10px);
	  filter:blur(10px);
	}
	.box{
	  position:absolute;
	  height:100%;
	  width:100%;
	  font-family:Helvetica;
	  color:#fff;
	  background:rgba(0,0,0,0.34);
	  padding:30px 0px;
	}
	h1{
	text-align:center;
	  margin:30px 0;
	  font-size:30px;
	  color:#fff;
	}
	h4{
	text-align:center;
	  margin:30px 0;
	  font-size:30px;
	  color:#fff;
	}
	.box h1{
	  text-align:center;
	  margin:30px 0;
	  font-size:30px;
	}
	.box input{
	  display:block;
	  width:300px;
	  margin:20px auto;
	  padding:15px;
	  background:#c2c2a3
	  color:#333;
	  border:0;
	}
	.box input:focus,.box input:active,.box button:focus,.box button:active{
	  outline:none;
	}
	.box button{
	  background:#6b6b47;
	  border:0;
	  color:#fff;
	  padding:10px;
	  font-size:20px;
	  width:330px;
	  margin:20px auto;
	  display:block;
	  cursor:pointer;
	}
	.box button:active{
	  background:#27ae60;
	}
	.box p{
	  font-size:14px;
	  text-align:center;
	}
	.box p span{
	  cursor:pointer;
	  color:#333;
	}
	img{
		width:100%;
		margin:0;
		padding:0;
		
	}
	a{
		text-decoration:none;
		size:44pt;
		text-align:left;
		background:#6b6b47;
		  border:0;
		  color:#fff;
		  padding:10px;
		  font-size:20px;
		  width:330px;
		  margin:20px auto;
		  display:block;
		  cursor:pointer;
	}
	</style>
	</head>
<body>
		<div class="col-12">
			<image src="<?php echo base_url('assets/image/PeNsia.png');?>">
		</div>
		<div class="col-12">
		<h1> Welcome,Make a good content for around,do Best !!!!! </h1>
		<h4> This Login just for Admin</h4>
		</div>
		<a href="<?php echo site_url('welcome/index');?>">KLIK HERE TO BACK TO HOME</a>
		<div class="vid-container">
  <div class="inner-container">
    <div class="box">
		
      <h1>Login</h1>
	  <form action="<?php echo site_url('login/can_login')?>" method="post">
      <input type="text" name="username"placeholder="Username"/ required>
      <input type="password" name="password"placeholder="Password"/ required>
      <button type="submit" value="login">Login</button>
	  <button type="reset">Reset</button>
	
	  </form>

    </div>
  </div>
</div>
	<div class="col-12">
<footer class="footer-distributed">

			<div class="footer-left">

				<img src="<?php echo base_url('assets/image/PeNsia.png');?>" style="width:100%">
				<br>
				<br>
				<br>
				<br>

				<p class="footer-company-name">PeNsia-Devi Aprilia Ayu S.; 2018</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Jl.Kaluta No.28</span> Malang,Indonesia</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+6288210820780</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">tugasku.devi@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About Founder</span>
					Hello Kenalkan Saya Devi Aprilia Ayu Santoso
					Saya Mahasiswi Manajemen Informatika
					Let me say that life is short and do best for you and around
				</p>

				<div class="footer-icons">

					<a href="https://www.facebook.com/devialde"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/deviaprilia_as"><i class="fa fa-twitter"></i></a>
					<a href="https://www.linkedin.com/in/devi-aprilia-ayu-santoso-149354163/"><i class="fa fa-linkedin"></i></a>

				</div>

			</div>
	</footer>
	
	</div>	
</body>
</html>