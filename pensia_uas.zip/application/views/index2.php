<html>
	<head>
	<title> Home</title>
	<link rel="shortcut icon" type="image/jpg"href="<?php echo base_url('assets/P.jpg');?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>" >
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />
	<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/footer-distributed-with-address-and-phones.css');?>">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/stylekal.css');?>"
	
	</head>
<body>
	<?php 
	if(isset($_POST['hitung'])){
		$berat = $_POST['bb'];
		$tinggi = $_POST['tb'];
		$operasi = $_POST['operasi'];
		switch ($operasi) {
			case 'tambah':
				$hasil = ($berat/($tinggi/100));
			break;
			case 'ulangi':
				$hasil=0;
					
		}
	}
	?>
		<div class="col-12">
			<image src="<?php echo base_url('assets/image/PeNsia.png');?>">
		</div>

		<div class="navbar">
			<div class="col-12">
				<div class="col-2">
				<a href="<?php echo site_url('welcome/index/');?>">Home</a>
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn">Do More 
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/care');?>">Caring </a>
						  <a href="<?php echo site_url('welcome/share');?>">Sharing</a>
						  <a href="<?php echo site_url('welcome/help');?>">Helping</a>
						</div>
					</div> 
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn">E-Nsia 
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/sos');?>">Sosial</a>
						  <a href="<?php echo site_url('welcome/psi');?>">Psikologi</a>
						  <a href="<?php echo site_url('welcome/kes');?>">Kesehatan</a>
						</div>
					</div> 
				</div>
			<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/hukum');?>">Hukum</a>
					</div>
				</div>
				<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/adu');?>">Pengaduan</a>
					</div>
				</div>
				<div class="col-2">
				<div class="alig">
					<a href="<?php echo site_url('welcome/login');?>">Login</a>
				</div>	
				</div>
			</div>
		</div>
	<div class="col-12">
				<h1> Home </h1>
			</div>	
	<div class="col-12">		
				<div class="col-4">
					<div class="kalkulator">
					<form method="post" action="index.php">			
						<input type="text" name="bb" class="bil" autocomplete="off" placeholder="Masukkan Berat Badan(KG)" required>
						<input type="text" name="tb" class="bil" autocomplete="off" placeholder="Masukkan Tinggi Badan(CM)" required>
						<select class="opt" name="operasi">
							<option value="tambah">Hasil</option>
							<option value="ulangi">Ulangi</option>
						</select>
						<input type="submit" name="hitung" value="Hitung" class="tombol">
						<input type="reset" value="reset"class="tombol">	
					</form>
					<?php if(isset($_POST['hitung'])){ ?>
						<input type="text" value="<?php echo $hasil; ?>" class="bil">
						<input type="reset" value="reset">
					<?php }else{ ?>
						<input type="text" value="0" class="bil">
					<?php } ?>			
				</div>
				</div>
				<div class="col-8">
				<div class="jdl">Menyesal Hidup Lama, Lansia Berusia 104 Tahun Minta Disuntik Mati</div>
					<div class="box1">
					
					<img src="https://cdn1-a.production.images.static6.com/oF6JeoLvoBFHlE4RbLry4cqHgec=/640x360/smart/filters:quality(75):strip_icc():format(jpeg)/liputan6-media-production/medias/2158286/original/097187000_1525431701-9bdfb0455aeae6437bc7e93a452b0edf.jpg" class="col-8">
					
					<p> Liputan6.com, Jakarta David Goodall, dikaruniai umur panjang hingga melampaui satu abad. Pria asal Inggris tersebut melewati dua perang dunia,
					20 piala dunia serta menyaksikan sejarah manusia menginjakkan kaki di bulan.</p>	
					<p>Semasa hidup pria 104 tahun ini telah menyaksikan berbagai kejadian sejarah penting yang telah dialami dunia. 
					Nyatanya, memiliki umur yang panjang justru tak membuatnya bahagia. Malahan pria kelahiran 1914 itu, mengungkapkan rasa penyesalannya karena hidup begitu lama.</p>
					<p>
					Goodall yang tinggal di Australia sejak tahun 1948 itu memutuskan ingin mengakhiri hidupnya. "Saya sangat menyesal telah mencapai usia itu. Saya tidak senang, saya ingin mati," ujar Goodall kepada ABC, dikutip dari Lad Bible.
Menurutnya, jika seseorang memang ingin membunuh dirinya sendiri, maka itu cukup adil. Baginya, orang lain tak perlu harus ikut campur ketika ia memilih keputusan untuk mengakhiri hidup.
Ternyata pilihan Goodal untuk mengakhiri hidup tidak legal bagi Pemerintah Australia Barat. Mereka masih menimbangkan kelegalan hukum euthanasia sukarela, yang sebenarnya hanya berlaku untuk orang yang sakit parah.
					</p>
					

					</div>
					</div>
</div>					
					<div class="col-12">
					<center>
					<div class="pagination">
					<a href="<?php echo site_url('Welcome/index');?>">&laquo;</a>
					<a href="<?php echo site_url('Welcome/index');?>">1</a>
					<a href="<?php echo site_url('Welcome/index2');?>"  class="active">2</a>
					<a href="<?php echo site_url('welcome/index3');?>">3</a>
					<a href="<?php echo site_url('welcome/index4');?>">4</a>
					<a href="#">&raquo;</a>
					
					</div>
					</center>
					</div>
	<div class="col-12">
	<footer class="footer-distributed">

			<div class="footer-left">

				<img src="<?php echo base_url('assets/image/PeNsia.png"');?>"  style="width:100%">
				<br>
				<br>
				<br>
				<br>

				<p class="footer-company-name">PeNsia-Devi Aprilia Ayu S.; 2018</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Jl.Kaluta No.28</span> Malang,Indonesia</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+6288210820780</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">tugasku.devi@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About Founder</span>
					Hello Kenalkan Saya Devi Aprilia Ayu Santoso
					Saya Mahasiswi Manajemen Informatika
					Let me say that life is short and do best for you and around
				</p>

				<div class="footer-icons">

					<a href="https://www.facebook.com/devialde"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/deviaprilia_as"><i class="fa fa-twitter"></i></a>
					<a href="https://www.linkedin.com/in/devi-aprilia-ayu-santoso-149354163/"><i class="fa fa-linkedin"></i></a>

				</div>

			</div>
	</footer>
	</div>	
</body>
</html>