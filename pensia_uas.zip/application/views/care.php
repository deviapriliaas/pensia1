<html>
	<head>
	<title>Caring</title>
	<link rel="shortcut icon" type="image/jpg"href="<?php echo base_url('assets/P.jpg');?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>" >
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />
	<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/stylesh.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/footer-distributed-with-address-and-phones.css');?>">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/stylecare.css');?>">
	
	</head>
<body>
		<div class="col-12">
			<image src="<?php echo base_url('assets/image/PeNsia.png');?>">
		</div>
				<div class="navbar">
			<div class="col-12">
				<div class="col-2">
				<a href="<?php echo site_url('welcome/index/');?>">Home</a>
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn"><div class="active">Do More</div> 
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/care/');?>">Caring </a>
						  <a href="<?php echo site_url('welcome/share/');?>">Sharing</a>
						  <a href="<?php echo site_url('welcome/help/');?>">Helping</a>
						</div>
					</div> 
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn">E-Nsia
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/sos/');?>">Sosial</a>
						  <a href="<?php echo site_url('welcome/psi/');?>">Psikologi</a>
						  <a href="<?php echo site_url('welcome/kes/');?>">Kesehatan</a>
						</div>
					</div> 
				</div>
			<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/hukum/');?>">Hukum</a>
					</div>
				</div>
				<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/adu/');?>">Pengaduan</a>
					</div>
				</div>
				<div class="col-2">
				<div class="alig">
					<a href="<?php echo site_url('welcome/login/');?>">Login</a>
				</div>	
				</div>
			</div>
		</div>	
		<div class="col-12">
			<h2>Caring</h2>
		</div>
		<div class="col-12">
			<div class="care">
		<p> Caring merupakan halaman dimana teman-teman yang mengunjungi website ini 
		bisa ikut melihat kondisi panti jompo dan melihat daftar panti jompo yang terdaftar di website ini,
		Jika teman-teman ingin menyisihkan rezekinya dan menjadi volunteer atau ikut membantu secara langsung mereka teman-teman bisa langsung ke <a href="<?php echo site_url('welcome/share');?>">SHARING</a> & <a href="<?php echo site_url('welcome/help');?>">HELPING</a>
		(<B>GUNAKAN KODE PANTI</B>)dengan fitur ini teman-teman bisa memilih sendiri Panti Jompo yang ingin diberikan donasi
		dan kami sebagai penanggungjawab akan memberikan donasi terhadap mereka.</p>
		
		<p> Sebagai bentuk pertanggungjawaban kami terhadap donasi yang diberikan kami akan memberikan bukti berupa
		foto dan surat serah terima atau donatur sendiri ikut mengunjungi saat donasi berlangsung, semua terserah kepada donatur,
		kami hanya sebagai penyalur dan memberikan informasi.</p>
		<br>
			</div>
		</div>		
		<div class="col-12">
			<h2> Keadaan Lansia Dan Panti Jompo</h2>
		</div>
		
	<div class="keadaan">	
		<div class="col-3">
		<img src="<?php echo base_url('assets/image/care/1.jpeg');?>"
		title="http://images.detik.com/community/media/visual/2017/12/08/be50351b-5a6d-40f7-b590-9e2767469c17_169.jpeg?w=780&q=90"
		>
		<p>ini salah contoh nasib lansia yang diterlantarkan anaknya,
		ia mengaku jika ia pernah di panti jompo namun keadaan panti jompo yang menyatukan
		lansia dengan orang gila membuatnya kabur dari panti jompo sementara anaknya yang dikabarkan dari <i>tribunnews bogor</i>
		sudah tidak "ingin" lansia ini lagi .<br>
		<p>sumber :<a href="http://bogor.tribunnews.com/2017/12/08/kabur-dari-panti-jompo-karena-disatukan-dengan-orang-gila-respon-anak-kakek-ini-menggeramkan">Tribunnews bogor</a></p>
		</p>
		</div>
	</div>

<div class="keadaan">	
		<div class="col-3">
		<img src="<?php echo base_url('assets/image/care/2.jpg');?>"
		title="http://cdn2.tstatic.net/jogja/foto/bank/images/mbah-poniyem_20161103_130228.jpg"
		>
		<p>nenek renta ini dalam kondisi gangguan jiwa dan ia tinggal sendirian
dalam gubuk reyot dengan beralaskan karung,diketahui bahwa ia tinggal sendiri karena sudah tidak memiliki 
sanak famili.Seperti yang sudah dikabarkan Tribunnews Jogja,Lansia ini sudah ditangani pemerintah<br>
		<p>sumber :<a href="http://jogja.tribunnews.com/2016/11/03/memilukan-lansia-gangguan-jiwa-tinggal-sendiri-di-gubuk-reyot-tak-berlampu-dan-tanpa-pintu">Tribunnews Jogja</a></p>
		</p>
		</div>
	</div>	
	
<div class="keadaan">	
		<div class="col-3">
		<img src="https://www.potretnews.com/assets/news/29012017/potretnewscom_rxyk8_9976.jpg"
		title="https://www.potretnews.com/assets/news/29012017/potretnewscom_rxyk8_9976.jpg"
		>
		<p>Ini salah satu kondisi panti jompo yang tidak layak.tempat ini 
         memiliki panti jompo,dimana penghuni disana bisa dikataan hidup secara tidak layak
		sesuai berita dari potret news.Mulai dari tempat tinggal sampai kamar mandi,kasus ini terkuak saat 
		balita yang meninggal secara tidak wajar.<br>
		<p>sumber :<a href="https://www.potretnews.com/berita/baca/2017/01/29/astagfirullah-betulbetul-tak-manusiawi-begini-kondisi-panti-jompo-dan-gangguan-jiwa-milik-yayasan/">Potret News</a></p>
		</p>
		</div>
</div>	

<div class="keadaan">	
		<div class="col-3">
		<img src="http://www.pilarbangsa.com/wp-content/uploads/2017/10/idris1.jpg" title="http://www.pilarbangsa.com/wp-content/uploads/2017/10/idris1.jpg"		>
		<p>Seorang Lansia dan istrinya hanya berharap pindah ke panti jompo karena keadaan mereka yang sudah tidak 
		layak lagi,mereka dari kecil sudah hidup sebatang kara dan saat tua sebatang kara,mereka mengatakan 
		hanya menunggu kematian jadi tolong dipindahkan ke panti jompo.<br>
		<p>sumber :<a href="http://www.pilarbangsa.com/pasrah-dalam-kehidupan/">Pilar Bangsa</a></p>
		</p>
		</div>
</div>	
<div class="col-12">
	<h5> Dilihat beberepa kondisi lansia dan panti jompo yang ada harus menyadarkan bahwasanya kita sebagai manusiawi
	tidak boleh melupakan orangtua baik orangtua kita sendiri atau lainnya,kita bisa mengulurkan tangan kita baik menjadi volunteer ataupun donatur.</h5>
</div>

<div class="col-12">
<h2> Daftar Panti Jompo untuk Donatur dan Volunteer</h2>
</div>
			<div class="col-12">
				<div class="box11">
				<table>
					<tr>
						<th>Kode</th>
						<th>Nama Panti Jompo</th>
						<th>Alamat Panti Jompo</th>
						<th>Telepon</th>
						</tr>
						<?php 
						foreach ($tampil as $r){?>
						<tr> 
						<td><?php echo $r['kodep']?></td>
						<td><?php echo $r['namaPJ']?></td>
						<td><?php echo $r['alamat']?></td>
						<td><?php echo $r['telp']?></td>
						
						</tr>
						<?php }?>
				</table>
				</div>
					
			</div>
			<div class="pag">
				<?php $pagination; ?>
			</div>
<div class="col-12">
<div class="box11">
NOTE:**CATAT KODE PANTI UNTUK VOLUNTEER DAN DONATUR**
</div>
</div>			
	<div class="col-12">
				<div class="box12">
				<table>
					<tr>
						<th>Kode</th>
						<th>Penjelasan</th>
					</tr>
					<tr>
					<td> 2</td>
					<td>Angka awal 2 untuk daerah Bandung</td>
					</tr>
					<tr>
					<td>1</td>
					<td>Angka awal 1 untuk daerah Malang</td>
					</tr>
					<tr>
					<td>3 </td>
					<td>Angka Awal 3 untuk daerah Jakarta</td>
					</tr>
					<tr>
					<td>4</td>
					<td> Angka Awal 4 untuk daerah Banten</td>
					</tr>
					<tr>
					<td>5</td>
					<td> Angka awal 5 untuk daerah Sumatra Barat</td>
					</tr>
					<tr>
					<td>6</td>
					<td>Angka Awal 6 untuk daerah Bali</td>
					</tr>
					
				</table>
				</div>
					
			</div>					
	<div class="col-12">
	<footer class="footer-distributed">

			<div class="footer-left">

				<img src="<?php echo base_url('assets/image/PeNsia.png');?>" style="width:100%">
				<br>
				<br>
				<br>
				<br>

				<p class="footer-company-name">PeNsia-Devi Aprilia Ayu S.; 2018</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Jl.Kaluta No.28</span> Malang,Indonesia</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+6288210820780</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">tugasku.devi@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About Founder</span>
					Hello Kenalkan Saya Devi Aprilia Ayu Santoso
					Saya Mahasiswi Manajemen Informatika
					Let me say that life is short and do best for you and around
				</p>

				<div class="footer-icons">

					<a href="https://www.facebook.com/devialde"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/deviaprilia_as"><i class="fa fa-twitter"></i></a>
					<a href="https://www.linkedin.com/in/devi-aprilia-ayu-santoso-149354163/"><i class="fa fa-linkedin"></i></a>

				</div>

			</div>
	</footer>
	</div>	
</body>
</html>