<html>
	<head>
	<title>Share</title>
	<link rel="shortcut icon" type="image/jpg"href="<?php echo base_url('assets/P.jpg');?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>" >
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />
	<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/stylesh.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/footer-distributed-with-address-and-phones.css');?>">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">

	</head>
<body>
		<div class="col-12">
			<image src="<?php echo base_url('assets/image/PeNsia.png');?>">
		</div>
				<div class="navbar">
			<div class="col-12">
				<div class="col-2">
				<a href="<?php echo site_url('welcome/index/');?>">Home</a>
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn"><div class="active">Do More</div> 
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/care/');?>">Caring </a>
						  <a href="<?php echo site_url('welcome/share/');?>">Sharing</a>
						  <a href="<?php echo site_url('welcome/help/');?>">Helping</a>
						</div>
					</div> 
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn">E-Nsia
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/sos/');?>">Sosial</a>
						  <a href="<?php echo site_url('welcome/psi/');?>">Psikologi</a>
						  <a href="<?php echo site_url('welcome/kes/');?>">Kesehatan</a>
						</div>
					</div> 
				</div>
			<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/hukum/');?>">Hukum</a>
					</div>
				</div>
				<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/adu/');?>">Pengaduan</a>
					</div>
				</div>
				<div class="col-2">
				<div class="alig">
					<a href="<?php echo site_url('welcome/login/');?>">Login</a>
				</div>	
				</div>
			</div>
		</div>	
		<div class="col-12">
			<h2>Sharing</h2>
		</div>
		<div class="col-12">
			<div class="bg">
		<p> Sharing merupakan halaman dimana teman-teman yang mengunjungi website ini 
		bisa ikut berpartisipasi dengan menyisihkan sedikit rezekinya untuk orangtua yang ada 
		di panti jompo,dengan fitur ini teman-teman bisa memilih sendiri Panti Jompo yang ingin diberikan donasi
		dan kami sebagai penanggungjawab akan memberikan donasi terhadap mereka.</p>
		
		<p> Sebagai bentuk pertanggungjawaban kami terhadap donasi yang diberikan kami akan memberikan bukti berupa
		foto dan surat serah terima atau donatur sendiri ikut mengunjungi saat donasi berlangsung, semua terserah kepada donatur,
		kami hanya sebagai penyalur dan memberikan informasi.</p>
		<br>
		
		<div class="col-3">
			<div class="pantun1">
		<b>
		<p> IKAN LAYANG DI AWAN</p>
		<p> PAGAR PUAN DARI KELAPA<p>
		<p> MARI BERBAGI SAYANG KAWAN</p>
		<p> AGAR NYAMAN DAMAI TERCIPTA</p>
		</b>
			</div>
		</div>
		<div class="col-3">
			<div class="pantun2">
		<b>
		<p> JIKA TUAN KE KOTA LAMA</p>
		<p> JANGAN LUPA BELI BUAH<p>
		<p> JIKA ITU SUDAH TERCIPTA</p>
		<p> TAK'KAN LAGI ADA YANG BERSEDIH</p>
		</b>
			</div>
		</div>
		<div class="col-3">
			<div class="pantun3">
		<b>
		<p> PASIR TERTAWA DENGAN LAUT</p>
		<p> TUAN TERTAWA DENGAN PUAN<p>
		<p> JANGAN BIARKAN MEREKA TAKUT</p>
		<p> TEMANI MEREKA SEPERTI TEMAN</p>
		</b>
			</div>
		</div>
		<div class="col-3">
			<div class="pantun4">
		<b>
		<p> NONA MANIS SUKA JAGUNG</p>
		<p> ABANG TAMPAN SUKA JALAN<p>
		<p> MARI SALING MENGAUNG</p>
		<p> AUNGKAN KEBAIKAN</p>
		</b>
			</div>
		</div>
		
			</div>
		</div>		
		<div class="col-12">
			<h2> Let's Sharing</h2>
			<div class="col-12">
		<h4> SILAHKAN ISI FORM UNTUK DONASI </h4>
		<form action="<?=site_url('welcome/tambahDonatur');?>" method="post">
			<table>
	
				<tr>
					<td><input type="text" name="kode" placeholder="Masukkan Kode Panti" size="39" required></td>
				</tr>
				<tr>
					<td> <input type="text" name="namaD" placeholder="Masukkan Nama Anda" size="39" required>
				</tr>
				<tr>
					<td> <input type="text" name="no_hp" placeholder="Masukkan Nomor Hp Anda" size="39" required>
				</tr>
				<tr>
					<td><select name="bank" required> 
					<option> Pilih Salah Satu Bank</option>
					<option value="bni">BNI
					<option value="BRI">BRI
					<option value="bca">BCA
					<option value="btn">BTN
					<option value="niaga">Bank Niaga
					</td>
				</tr>
				
				<tr>
				<td><input type="text" name="nominal" placeholder="Jumlah yang ingin diberikan(IDR)" size="39"required></td>
				</tr>
				<tr>
				<td><input type="text" placeholder="Masukkan Nomor Kartu Debit Anda" size="39"required></td>
				</tr>
				<tr>
				<td><input type="text" placeholder="Masukkan CV/CVV Kartu Anda" size="39"required></td>
				</tr>
				<tr>
				<td><input type="text" placeholder="Masukkan Kode OTP yang kami kirimkan" size="39"required></td>
				</tr>
				<tr>
				<td><input type="date" name="tanggal"required></td>
				</tr>
				<tr>
				<td><button type="submit" value="submit">Kirim</button><button type="reset">Reset</button></td>
				</tr>
			</table>
		
		</form>
		</div>	
			
<div class="col-12">
<h2> Indahnya Berbagi</h2>
</div>
			<div class="col-12">
				<div class="col-3">		
						<div class="bulat">
						<img src="<?php echo base_url('assets/image/share/p1.png');?>" title="Yayasan Buddha Tzu Chi Indonesia">
						<div class="box11">
							“Dan belanjakanlah (harta bendamu) di jalan Allah, dan janganlah kamu menjatuhkan dirimu sendiri ke dalam kebinasaan, dan berbuat baiklah, karena sesungguhnya Allah menyukai orang-orang yang berbuat baik.” (QS. Al Baqarah:195)
						</div>
						</div>
				</div>	
					<div class="col-3">
						<div class="bulat">
						<img src="<?php echo base_url('assets/image/share/p2.png');?>" title="poskotanews.com">
						</div>
						<div class="box11">
							Berilah dan kamu akan diberi: suatu takaran yang baik, yang dipadatkan, yang digoncang dan yang tumpah ke luar akan dicurahkan ke dalam ribaanmu. Sebab ukuran yang kamu pakai untuk mengukur, akan diukurkan kepadamu.(Lukas 6:38)
						</div>
					</div>
					<div class="col-3">
						<div class="bulat">
						<img src="<?php echo base_url('assets/image/share/p3.png');?>" title="tzuchi.or.id">
						</div>
						<div class="box11">
							Kedermawanan yang diberikan karena kewajiban, tanpa mengharapkan pamrih, pada waktu dan tempat yang tepat, kepada orang yang patut menerimanya dianggap bersifat kebaikan. (Bhagavad-gita 17.20)
						</div>
					</div>	

					<div class="col-3">
						<div class="bulat">
						<img src="<?php echo base_url('assets/image/share/p4.png');?>" title="tzuchi.or.id">
						</div>
						<div class="box11">
							“Dan belanjakanlah (harta bendamu) di jalan Allah, dan janganlah kamu menjatuhkan dirimu sendiri ke dalam kebinasaan, dan berbuat baiklah, karena sesungguhnya Allah menyukai orang-orang yang berbuat baik.” (QS. Al Baqarah:195)
						</div>
					</div>	
					
			</div>		
	<div class="col-12">
	<footer class="footer-distributed">

			<div class="footer-left">

				<img src="<?php echo base_url('assets/image/PeNsia.png');?>" style="width:100%">
				<br>
				<br>
				<br>
				<br>

				<p class="footer-company-name">PeNsia-Devi Aprilia Ayu S.; 2018</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Jl.Kaluta No.28</span> Malang,Indonesia</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+6288210820780</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">tugasku.devi@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About Founder</span>
					Hello Kenalkan Saya Devi Aprilia Ayu Santoso
					Saya Mahasiswi Manajemen Informatika
					Let me say that life is short and do best for you and around
				</p>

				<div class="footer-icons">

					<a href="https://www.facebook.com/devialde"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/deviaprilia_as"><i class="fa fa-twitter"></i></a>
					<a href="https://www.linkedin.com/in/devi-aprilia-ayu-santoso-149354163/"><i class="fa fa-linkedin"></i></a>

				</div>

			</div>
	</footer>
	</div>	
</body>
</html>