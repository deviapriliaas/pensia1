<html>
	<head>
	<title>Helping</title>
	<link rel="shortcut icon" type="image/jpg"href="<?php echo base_url('assets/P.jpg');?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>" >
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />
	<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/stylesh.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/footer-distributed-with-address-and-phones.css');?>">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/stylecare.css');?>">
	
	</head>
<body>
		<div class="col-12">
			<image src="<?php echo base_url('assets/image/PeNsia.png');?>">
		</div>
				<div class="navbar">
			<div class="col-12">
				<div class="col-2">
				<a href="<?php echo site_url('welcome/index/');?>">Home</a>
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn"><div class="active">Do More</div> 
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/care/');?>">Caring </a>
						  <a href="<?php echo site_url('welcome/share/');?>">Sharing</a>
						  <a href="<?php echo site_url('welcome/help/');?>">Helping</a>
						</div>
					</div> 
				</div>
				<div class="col-2">
					<div class="dropdown">
						<button class="dropbtn">E-Nsia
						  <i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-content">
						  <a href="<?php echo site_url('welcome/sos/');?>">Sosial</a>
						  <a href="<?php echo site_url('welcome/psi/');?>">Psikologi</a>
						  <a href="<?php echo site_url('welcome/kes/');?>">Kesehatan</a>
						</div>
					</div> 
				</div>
			<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/hukum/');?>">Hukum</a>
					</div>
				</div>
				<div class="col-2">
					<div class="sembunyi">
					<a href="<?php echo site_url('welcome/adu/');?>">Pengaduan</a>
					</div>
				</div>
				<div class="col-2">
				<div class="alig">
					<a href="<?php echo site_url('welcome/login/');?>">Login</a>
				</div>	
				</div>
			</div>
		</div>	
		<div class="col-12">
			<h2>Caring</h2>
		</div>
		<div class="col-12">
			<div class="care">
				<p> Helping merupakan halaman dimana teman-teman yang mengunjungi website ini 
				bisa ikut menjadi volunteer yang melayani langsung para lansia di panti jompo yang
				teman-teman pilih.</p>
		
				<p> Setelah mendaftar teman-teman akan menerima SMS dari admin untuk langkah selanjutnya yakni ke panti jompo bersama dengan admin</p>
				<br>
			</div>
		</div>
		
		<div class="col-12">
			<h2> Form Untuk Mendaftar Menjadi Volunteer</h2>
		</div>
		<div class="col-12">
		<h4> SILAHKAN ISI FORM</h4>
<form action="<?php echo base_url(). 'index.php/welcome/tambahV'; ?>" method="post">
			<table>
				<tr>
					<td><input type="text" name="kodeV" placeholder="Kode Panti Jompo" size="39" required></td>
				</tr>
				<tr>
					<td><input type="text" name="namaV" placeholder="Masukkan Nama Anda" size="39" required></td>
				</tr>
				<tr>
					<td> <input type="text" name="alamatV" placeholder="Alamat Anda" size="39" required>
				</tr>
				<tr>
					<td> <input type="text" name="no_telp" placeholder="Masukkan No Hp Anda" size="39" required>
				</tr>
				<tr>
					<td> <input type="text" name="no_ktp" placeholder="Masukkan No KTP anda" size="39" required>
				</tr>
				<tr>
				<td><select name="kategori" required>
				<option>Kategori Volunteer</option>
				<option value="Merawat Lansia">Merawat Lansia</option>
				<option value="Memasak untuk Lansia">Memasak Untuk Lansia</option>
				<option value="Membersihkan Panti Jompo">Membersihkan Panti Jompo</option>
				</td>
				</tr>
				<tr>
				<td><button type="submit" value="simpan">Kirim</button><button type="reset">Reset</button></td>
				</tr>
			</table>
			
		</form>	
	</div>
	
	<div class="col-12">
	<h5>Saya Tidak Bisa Menjanjikan bahwa anda akan terkenal karena membantu tapi 
saya bisa menjanjikan bahwa anda akan sangat senang karena saling membantu,Salam Berhati Besar! Caring,Sharing and Helping > PeNSia	</h5>
</div>
	
	<div class="col-12">
	<footer class="footer-distributed">

			<div class="footer-left">

				<img src="<?php echo base_url('assets/image/PeNsia.png');?>" style="width:100%">
				<br>
				<br>
				<br>
				<br>

				<p class="footer-company-name">PeNsia-Devi Aprilia Ayu S.; 2018</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Jl.Kaluta No.28</span> Malang,Indonesia</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+6288210820780</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">tugasku.devi@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About Founder</span>
					Hello Kenalkan Saya Devi Aprilia Ayu Santoso
					Saya Mahasiswi Manajemen Informatika
					Let me say that life is short and do best for you and around
				</p>

				<div class="footer-icons">

					<a href="https://www.facebook.com/devialde"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/deviaprilia_as"><i class="fa fa-twitter"></i></a>
					<a href="https://www.linkedin.com/in/devi-aprilia-ayu-santoso-149354163/"><i class="fa fa-linkedin"></i></a>

				</div>

			</div>
	</footer>
	</div>	
</body>
</html>