<html>
	<head>
	<title>Edit Data Panti Jompo</title>
	<link rel="shortcut icon" type="image/jpg"href="<?php echo base_url('assets/P.jpg');?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css');?>" >
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />
	<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/stylesh.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/footer-distributed-with-address-and-phones.css');?>">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/stylecare.css');?>">
	
	</head>
<body>
		
		<div class="col-12">
			<h2> Edit Data Panti Jompo</h2>
		</div>
		<div class="col-12">
		<h4> FORM DATA PANTI JOMPO</h4>
<form action="<?=site_url('admin/update/'.$data->no);?>" method="post">
			<table>
				<tr>
					<td><input type="text" name="kodep" value="<?php echo $data->kodep?>"placeholder="Kode Panti"size="39" required></td>
				</tr>
				<tr>
					<td><input type="text" name="namaPJ" value="<?php echo $data->namaPJ?>"placeholder="Masukkan Nama Panti Jompo" size="39" required></td>
				</tr>
				<tr>
					<td> <input type="text" name="alamat" value="<?php echo $data->alamat?>"placeholder="Alamat Panti Jompo"size="39" required>
				</tr>
				<tr>
					<td> <input type="text" name="telp" value="<?php echo $data->telp?>"placeholder="Masukkan Telp Panti"size="39" required>
				</tr>
				
				<tr>
				<td><button type="submit" value="submit">Simpan</button><button type="reset">Reset</button></td>
				</tr>
			</table>
			
		</form>
	</div>
	
	<div class="col-12">
	<footer class="footer-distributed">

			<div class="footer-left">

				<img src="<?php echo base_url('assets/image/PeNsia.png');?>" style="width:100%">
				<br>
				<br>
				<br>
				<br>

				<p class="footer-company-name">PeNsia-Devi Aprilia Ayu S.; 2018</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Jl.Kaluta No.28</span> Malang,Indonesia</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+6288210820780</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">tugasku.devi@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About Founder</span>
					Hello Kenalkan Saya Devi Aprilia Ayu Santoso
					Saya Mahasiswi Manajemen Informatika
					Let me say that life is short and do best for you and around
				</p>

				<div class="footer-icons">

					<a href="https://www.facebook.com/devialde"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/deviaprilia_as"><i class="fa fa-twitter"></i></a>
					<a href="https://www.linkedin.com/in/devi-aprilia-ayu-santoso-149354163/"><i class="fa fa-linkedin"></i></a>

				</div>

			</div>
	</footer>
	</div>	
</body>
</html>