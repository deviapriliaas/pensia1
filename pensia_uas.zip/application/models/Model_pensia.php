<?php
class Model_pensia extends CI_Model{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_pensia');
		$this->load->helper('url');
	}
	function get_panti_list ($limit, $start){
		$query = $this->db->get('pantij', $limit, $start);
		return $query;
	}
	function index()
	{
		$data['donatur']=$this->model_pensia->tampil_data();
		$this->load->view('sharen',$data);
	}
	function view_row()
	{
		return $this->db->get('donatur')->result();
	}
	function tambahDonatur($data)
	{
		$this->db->insert('donatur',$data);
	}
	public function get_donatur()
    {
	
		
		$sql = "SELECT donatur.kode, donatur.namaD,donatur.tanggal,donatur.nominal,pantij.namaPJ
		FROM pantij 
		INNER JOIN donatur
		ON donatur.kode=pantij.kodep;";
		$tampil = $this->db->query($sql);
		return $tampil->result(); 
    }
	function get_vol()
    {
		$sql = "SELECT volunteer.kodeV, volunteer.namaV,volunteer.alamatV,volunteer.kategori,pantij.namaPJ
		FROM pantij 
		INNER JOIN volunteer
		ON volunteer.kodeV=pantij.kodep;";
		$tampil = $this->db->query($sql);
		return $tampil->result(); 
    }
	public function get_volunteer($table)
	{
		$data=$this->db->get($table);
		return $data->result_array();
	}
	public function get_full_donatur($table)
	{
		$data=$this->db->get($table);
		return $data->result_array();
	}
	public function deleteD($namaD)
	{
		$this->db->delete('donatur',array('namaD'=>$namaD));
		return;
	}
	public function delete_panti($no)
    {
    	$this->db->delete('panti',array('no'=>$no));
    	return;
    }
	 public function get_panti($table)
    {
	
		$data=$this->db->get($table);
		return $data->result_array();   
    }
	public function tambahV($data)
	{
		$this->db->insert('volunteer',$data);
	}
	public function deleteV($kode)
	{
		$this->db->delete('volunteer',array('kode=>$kode'));
		return;
	}
}