<?php
class admin_model extends CI_Model{
	function get_panti_list($limit,$start)
	{
		$query=$this->db->get('panti',$limit,$start);
		return $query;
	}
	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
		$this->load->helper('url');
	}
	public function get_donatur()
    {
	
		
		$sql = "SELECT donatur.kode, donatur.namaD,donatur.tanggal,donatur.nominal,pantij.namaPJ
		FROM pantij 
		INNER JOIN donatur
		ON donatur.kode=pantij.kodep;";
		$tampil = $this->db->query($sql);
		return $tampil->result(); 
    }
	
	public function update_datap($no,$data)
	{
		try {
			$this->db->where('no',$no)->limit(1)->update('pantij',$data);
			return true;
		} catch(Exception $e){}
		
	}
		public function update_data($no,$data)
	{
		try {
			$this->db->where('no',$no)->limit(1)->update('pantij',$data);
			return true;
		} catch(Exception $e){}
		
	}
	
	function get_vol()
    {
		$sql = "SELECT volunteer.kodeV, volunteer.namaV,volunteer.alamatV,volunteer.kategori,pantij.namaPJ
		FROM pantij 
		INNER JOIN volunteer
		ON volunteer.kodeV=pantij.kodep;";
		$tampil = $this->db->query($sql);
		return $tampil->result(); 
    }
	public function get_volunteer($table)
	{
		$data=$this->db->get($table);
		return $data->result_array();
	}
	public function get_full_donatur($table)
	{
		$data=$this->db->get($table);
		return $data->result_array();
	}
	public function deleteD($namaD)
	{
		$this->db->delete('donatur',array('namaD'=>$namaD));
		return;
	}
	function tambahPanti($data)
	{
		$this->db->insert('pantij',$data);
	}
	public function delete_panti($no)
    {
    	$this->db->delete('pantij',array('no'=>$no));
    	return;
    }
	public function deleteV($kode)
	{
		$this->db->delete('volunteer',array('kode=>$kode'));
		return;
	}
	 public function get_panti($table)
    {
	
		$data=$this->db->get($table);
		return $data->result_array();   
    }
	function editp($no)
	{
		$this->db->where('no',$no);
		$query=$this->db->get('pantij');
		return $query->row();
	}
	
}	