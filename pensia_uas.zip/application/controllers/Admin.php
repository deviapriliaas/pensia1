<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	function __construct()
		{
		parent::__construct();
		$this->load->model('loginmodel');
		
			if($this->session->userdata('status') != "login")
			{
				redirect(base_url("index.php/welcome/login"));
			}
		}
	
	function deleteD()
 	{
 		$namaD= $this->uri->segment(3);
 		$this->admin_model->deleteD($namaD);
 		redirect('admin/datad');
 	}
	function get_full_donatur()
	{
		$this->data['hasil']=$this->admin_model->get_full_donatur('donatur');
		$this->load->view('datad',$this->data);
	}
	
	function tambahDonatur()
	{
		 $data = array(
		'kode'=>$this->input->post('kode'),
		'namaD'=>$this->input->post('namaD'),
		'no_hp'=>$this->input->post('no_hp'),
		'bank'=>$this->input->post('bank'),
		'nominal'=>$this->input->post('nominal'),
		'tanggal'=>$this->input->post('tanggal')
			);
		$this->model_pensia->tambahDonatur($data);
		redirect('welcome/cetakD');
		if($data==FALSE)
		{
			redirect('welcome/share');
		}
	}
	function tambahPanti()
	{
		 $data = array(
		'kodep'=>$this->input->post('kodep'),
		'namaPJ'=>$this->input->post('namaPJ'),
		'alamat'=>$this->input->post('alamat'),
		'telp'=>$this->input->post('telp')
			);
		$this->admin_model->tambahPanti($data);
		redirect('admin/datap');
	}
	
	function update($no)
	{
		 $data = array(
		'kodep'=>$this->input->post('kodep'),
		'namaPJ'=>$this->input->post('namaPJ'),
		'alamat'=>$this->input->post('alamat'),
		'telp'=>$this->input->post('telp')
			);
		$this->admin_model->update_datap($no,$data);
		redirect('admin/datap');
	}
	
	
	function tambahp()
	{
		
		$this->load->view('tambahp');
		
	}
	function datad()
	{
		$data['tampil']=$this->admin_model->get_full_donatur('donatur');
		$this->load->view('datad',$data);
	}
	function delete_panti()
 	{
 		$no = $this->uri->segment(3);
 		$this->admin_model->delete_panti($no);
 		redirect('admin/datap');
 	}
	function datap_do()
	{
		$data['tampil']=$this->admin_model->get_donatur();
		$this->load->view('datap_do',$data);
	}
	function datap_v()
	{
		$data['tampil'] = $this->admin_model->get_vol();
		$this->load->view('datap_v',$data);
		
	}
	function datav()
	{
		$this->data['tampil']=$this->admin_model->get_volunteer('volunteer');
		$this->load->view('datav',$this->data);
	}
	function datap()
	{
		$this->data['tampil']=$this->admin_model->get_panti('pantij');
		$this->load->view('datap',$this->data);
		
	}
	function editp($no)
	{
		$res['data']=$this->admin_model->editp($no);
		$this->load->view('editp',$res);
		
	}
	
}