<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct() {
	parent::__construct();
	$this->load->model('model_pensia');
	$this->load->library('pagination');
	
	
	}
	public function pag()
	{
		$config['base_url'] = site_url('Welcome/pag');
		$config['total_rows'] = $this->db->count_all('pantij');
		$config['per_page'] = 5;
		$config["uri_segment"] = 3;
		$choice = $config ["total_rows"]/ $config["per_page"];
		$config["num_links"] = floor($choice);
		

		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$config['full_tag_open'] = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center">';
		$config['full_tag_close'] = '</ul></nav></div>';
		$config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['num_tag_close'] = '</span></li>';
		$config['cur_tag_open'] = '<li class="page-item active"><span class="page-link">';
		$config['cur_tag_close'] = '<span class="sr-only">(current)</span></span></li>';
		$config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['next_tagl_close'] = '<span aria-hidden-"true">$raquo; </span></span></li>';
		$config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['prev_tagl_close'] = '</span>Next</li>';
		$config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['first_tagl_close'] = '</span></li>';
		$config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
		$config['last_tagl_close'] = '</span></li>';
		
		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3))? $this->uri->segment(3) :0;
		
		$data['data'] = $this->model_pensia->get_panti_list($config["per_page"], $data['page']);
		
		$data['pagination'] = $this->pagination->create_links();
		
		$this->load->view('care',$data);
	}

	public function index()
	{
		$this->load->view('index');
	}
	public function index2()
	{
		$this->load->view('index2');
	}
	public function index3()
	{
		$this->load->view('index3');
	}
	public function index4()
	{
		$this->load->view('index4');
	}
	public function hukum()
	{
		$this->load->view('hukum');
		
	}
	public function kes()
	{
		$this->load->view('kes');
		
	}
	public function sos()
	{
		$this->load->view('sos');
		
	}
	public function psi()
	{
		$this->load->view('psi');
		
	}
	public function adu()
	{
		$this->load->view('adu');
		
	}
	public function login()
	{
		$this->load->view('login');
		
	}
	public function share()
	{
		
		$this->load->view('share');
		
	}
	
	public function care()
	{
		
		$this->data['tampil']=$this->model_pensia->get_panti('pantij');
		$this->load->view('care',$this->data);
		
	}
	public function help()
	{
		$this->load->view('help');
		
	}
		public function sharen()
	{
		$this->load->view('sharen');
	}
	
	public function tambahDonatur()
	{
		 $data = array(
		'kode'=>$this->input->post('kode'),
		'namaD'=>$this->input->post('namaD'),
		'no_hp'=>$this->input->post('no_hp'),
		'bank'=>$this->input->post('bank'),
		'nominal'=>$this->input->post('nominal'),
		'tanggal'=>$this->input->post('tanggal')
			);
		$this->model_pensia->tambahDonatur($data);
		redirect('welcome/sharen');
	}
	public function deleteD()
 	{
 		$namaD= $this->uri->segment(3);
 		$this->model_pensia->deleteD($namaD);
 		redirect('welcome/datad');
 	}
	public function get_full_donatur()
	{
		$this->data['hasil']=$this->model_pensia->get_full_donatur('donatur');
		$this->load->view('datad',$this->data);
	}
	public function tambahV()
	{
		$data=array(
		'kodeV'=>$this->input->post('kodeV'),
		'namaV'=>$this->input->post('namaV'),
		'no_ktp'=>$this->input->post('no_ktp'),
		'alamatV'=>$this->input->post('alamatV'),
		'no_telp'=>$this->input->post('no_telp'),
		'kategori'=>$this->input->post('kategori')
		);
	$this->model_pensia->tambahV($data,'volunteer');
	redirect('welcome/sharen');
	}
	
	function cetak()
	{
		ob_start();
		$data['donatur']=$this->model_pensia->view_row();
		$this->load->view('print',$data);
		$html=ob_get_contents();
		ob_end_clean();
		
		require_once('./assets/html2pdf/html2pdf.class.php');
		$pdf=new HTML2PDF('P','A4','en');
		$pdf->WriteHTML($html);
		$pdf->output('Data Untuk Pensia.pdf','D');
	}
	public function cetakD()
	{
		
		$this->data['tampil']=$this->model_pensia->get_full_donatur('donatur');
		$this->load->view('cetakD',$this->data);
		
	}
	
}

